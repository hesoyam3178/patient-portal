export const BRAND = {
  subtitle: "Your health check results, in one place",
  logo: `${import.meta.env.BASE_URL}crt-logo.svg`,
  logoAlt: "College for Research and Technology, Cabanatuan seal",
} as const;
